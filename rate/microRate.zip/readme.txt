 *************************************************
 * Micro Rate
 *
 * Version: 1.0
 * Date: 2007-07-17
 *************************************************

Micro Rate is a very basic and simple rating script.
Visitors are identified by IP and only one rate per IP is allowed.
No database is required as results are stored in file.

Installation:

1. Upload all files to your web server.

Troubleshooting:

- Ratings are not updated
          1. A rating from one IP is only counted once
          2. Check if the results directory is writeable.
          
          
